#!/bin/sh
. ./n

clean_repo
#fined
#instruction

gitpush