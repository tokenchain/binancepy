"""An unofficial Python3 wrapper for the Binance Chain API

.. moduleauthor:: Sam McHardy

"""
import pkg_resources

__version__ = pkg_resources.get_distribution("binancepy").version
